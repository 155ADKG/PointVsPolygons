# PointVsPolygons
155ADKG / U1 / Project VAN / 2016 / group A

Compile with Qt Creator
-----------------------
        git clone https://github.com/155ADKG/PointVsPolygons.git
        open PointVsPolygon.pro in Qt Creator
